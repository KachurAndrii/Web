document.getElementById("applyColor").addEventListener("click", async () => {
    const color = document.getElementById("colorPicker").value;
    
    // Виконання скрипта на активній вкладці
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: changeBackgroundColor,
        args: [color]
    });
});

// Функція для зміни фону сторінки
function changeBackgroundColor(color) {
    document.body.style.backgroundColor = color;
}
