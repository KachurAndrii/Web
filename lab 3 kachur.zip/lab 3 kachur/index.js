import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js";
import { getDatabase, ref, push, onValue, remove } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-database.js";

const appSettings = {
    databaseURL: "https://my-project-d1c6d-default-rtdb.europe-west1.firebasedatabase.app/" 
}
// Ініціалізація Firebase
const firebaseApp = initializeApp(appSettings);
const db = getDatabase(firebaseApp);
const bucketListRef = ref(db, "bucketList");

// Елементи DOM
const goalInput = document.getElementById("input-field");
const categoryDropdown = document.getElementById("category-select");
const addGoalButton = document.getElementById("add-button");
const sortGoalsButton = document.getElementById("sort-button");
const goalList = document.getElementById("wish-list");

// Додавання нового запису
addGoalButton.addEventListener("click", function () {
    const goalText = goalInput.value.trim();
    const goalCategory = categoryDropdown ? categoryDropdown.value : "General";

    if (goalText) {
        push(bucketListRef, { text: goalText, category: goalCategory, createdAt: Date.now() });
        clearGoalInput();
    } else {
        alert("Please enter a goal!");
    }
});

// Завантаження даних у реальному часі
onValue(bucketListRef, function (snapshot) {
    if (snapshot.exists()) {
        const goalEntries = Object.entries(snapshot.val());
        clearGoalList();

        goalEntries.forEach(([id, goalData]) => appendGoalToList(id, goalData));
    } else {
        goalList.innerHTML = "<li>No goals added yet. Start planning your dreams!</li>";
    }
});

// Сортування за датою
if (sortGoalsButton) {
    sortGoalsButton.addEventListener("click", function () {
        onValue(bucketListRef, function (snapshot) {
            if (snapshot.exists()) {
                const sortedGoals = Object.entries(snapshot.val()).sort((a, b) => b[1].createdAt - a[1].createdAt);
                clearGoalList();

                sortedGoals.forEach(([id, goalData]) => appendGoalToList(id, goalData));
            }
        });
    });
}

// Очищення списку цілей
function clearGoalList() {
    goalList.innerHTML = "";
}

// Очищення поля вводу
function clearGoalInput() {
    goalInput.value = "";
}

// Додавання запису до списку
function appendGoalToList(goalId, goalData) {
    const { text, category } = goalData;

    const goalItem = document.createElement("li");
    const categoryLabel = document.createElement("span");

    goalItem.textContent = text;
    categoryLabel.textContent = `(${category})`;
    categoryLabel.className = "category-icon";

    goalItem.appendChild(categoryLabel);

    // Позначення виконаних цілей
    goalItem.addEventListener("click", function () {
        goalItem.classList.toggle("completed");
    });

    // Видалення запису
    goalItem.addEventListener("dblclick", function () {
        const goalRef = ref(db, `bucketList/${goalId}`);
        remove(goalRef);
    });

    goalList.appendChild(goalItem);
}